package com.example.meteorologicService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeteorologicServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
