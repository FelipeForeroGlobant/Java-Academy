package com.example.meteorologicService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeteorologicServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeteorologicServiceApplication.class, args);
	}

}
