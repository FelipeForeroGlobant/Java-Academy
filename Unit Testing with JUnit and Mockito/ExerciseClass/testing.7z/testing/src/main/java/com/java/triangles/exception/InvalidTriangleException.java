package com.java.triangles.exception;

public class InvalidTriangleException extends RuntimeException {

    public InvalidTriangleException(String message) {
        super(message);
    }
}
