package com.java.testing.util;

public class Validators {

    public static boolean isValidId(Integer id) {
        return id > 0;
    }
}
