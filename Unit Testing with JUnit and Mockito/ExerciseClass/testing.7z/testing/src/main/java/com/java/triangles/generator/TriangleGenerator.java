package com.java.triangles.generator;

import com.java.triangles.model.Triangle;

public interface TriangleGenerator {

    Triangle generateTriangle();

}
